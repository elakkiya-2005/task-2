import React, { useState, useMemo } from 'react';
import { BarChart3, Database, TrendingUp, Filter, RefreshCw } from 'lucide-react';
import { extendedTitanicData } from './data/titanicData';
import { DataTable } from './components/DataTable';
import { SummaryCards } from './components/SummaryCards';
import { Charts } from './components/Charts';
import { InsightsPanel } from './components/InsightsPanel';
import {
  calculateDataSummary,
  calculateSurvivalRates,
  getAgeDistribution,
  getFareDistribution,
  cleanData
} from './utils/dataAnalysis';

function App() {
  const [activeTab, setActiveTab] = useState<'overview' | 'data' | 'charts' | 'insights'>('overview');
  const [useCleanedData, setUseCleanedData] = useState(false);

  const currentData = useMemo(() => {
    return useCleanedData ? cleanData(extendedTitanicData) : extendedTitanicData;
  }, [useCleanedData]);

  const summary = useMemo(() => calculateDataSummary(currentData), [currentData]);
  const survivalRates = useMemo(() => calculateSurvivalRates(currentData), [currentData]);
  const ageDistribution = useMemo(() => getAgeDistribution(currentData), [currentData]);
  const fareDistribution = useMemo(() => getFareDistribution(currentData), [currentData]);

  const tabs = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'data', label: 'Dataset', icon: Database },
    { id: 'charts', label: 'Visualizations', icon: TrendingUp },
    { id: 'insights', label: 'Insights', icon: Filter },
  ] as const;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-xl shadow-lg">
                <BarChart3 className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Titanic Dataset Analysis</h1>
                <p className="text-gray-600 mt-1">Comprehensive Exploratory Data Analysis & Insights</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button
                onClick={() => setUseCleanedData(!useCleanedData)}
                className={`flex items-center px-4 py-2 rounded-lg border transition-colors duration-200 ${
                  useCleanedData
                    ? 'bg-green-50 border-green-200 text-green-700 hover:bg-green-100'
                    : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                }`}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                {useCleanedData ? 'Using Cleaned Data' : 'Use Cleaned Data'}
              </button>
            </div>
          </div>
          
          {/* Navigation Tabs */}
          <nav className="flex space-x-8 -mb-px">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4 mr-2" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <SummaryCards summary={summary} />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Dataset Overview</h2>
                  <div className="prose text-gray-700">
                    <p className="mb-4">
                      This analysis explores the famous Titanic dataset, examining passenger demographics, 
                      survival patterns, and the factors that influenced survival during the tragic sinking 
                      of the RMS Titanic on April 15, 1912.
                    </p>
                    <p className="mb-4">
                      The dataset contains information about {summary.totalPassengers} passengers including 
                      their age, gender, passenger class, fare paid, and most importantly, whether they 
                      survived the disaster.
                    </p>
                    <p>
                      Our analysis reveals significant patterns in survival rates based on gender, class, 
                      and age - providing insights into the social dynamics and evacuation procedures 
                      during this historic maritime disaster.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-6">
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
                  <h3 className="font-semibold text-blue-900 mb-3">Quick Stats</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Survival Rate:</span>
                      <span className="font-semibold text-blue-700">{summary.survivalRate.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Female Survival:</span>
                      <span className="font-semibold text-pink-700">{survivalRates.byGender.female.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Male Survival:</span>
                      <span className="font-semibold text-blue-700">{survivalRates.byGender.male.toFixed(1)}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">1st Class Survival:</span>
                      <span className="font-semibold text-purple-700">{survivalRates.byClass.first.toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-200">
                  <h3 className="font-semibold text-green-900 mb-3">Data Quality</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Complete Records:</span>
                      <span className="font-semibold text-green-700">
                        {((summary.totalPassengers - summary.missingAges - summary.missingFares) / summary.totalPassengers * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Missing Ages:</span>
                      <span className="font-semibold text-orange-700">{summary.missingAges}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Missing Fares:</span>
                      <span className="font-semibold text-orange-700">{summary.missingFares}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'data' && (
          <div className="space-y-6">
            <DataTable data={currentData} maxRows={20} />
            
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Data Cleaning Process</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-semibold text-blue-900 mb-2">Missing Ages</h4>
                  <p className="text-2xl font-bold text-blue-600">{summary.missingAges}</p>
                  <p className="text-sm text-gray-600 mt-1">Filled with median age</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <h4 className="font-semibold text-green-900 mb-2">Missing Fares</h4>
                  <p className="text-2xl font-bold text-green-600">{summary.missingFares}</p>
                  <p className="text-sm text-gray-600 mt-1">Filled with median fare</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <h4 className="font-semibold text-purple-900 mb-2">Missing Embarked</h4>
                  <p className="text-2xl font-bold text-purple-600">{summary.embarkedDistribution.unknown}</p>
                  <p className="text-sm text-gray-600 mt-1">Filled with 'S' (most common)</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'charts' && (
          <div className="space-y-8">
            <Charts 
              summary={summary}
              survivalRates={survivalRates}
              ageDistribution={ageDistribution}
              fareDistribution={fareDistribution}
            />
          </div>
        )}

        {activeTab === 'insights' && (
          <InsightsPanel summary={summary} survivalRates={survivalRates} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <p className="text-gray-600">
              Titanic Dataset Analysis - Exploratory Data Analysis Dashboard
            </p>
            <p className="text-sm text-gray-500 mt-2">
              Built with React, TypeScript, and Chart.js for comprehensive data visualization
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;