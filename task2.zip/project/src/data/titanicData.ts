export interface TitanicPassenger {
  PassengerId: number;
  Survived: number;
  Pclass: number;
  Name: string;
  Sex: string;
  Age: number | null;
  SibSp: number;
  Parch: number;
  Ticket: string;
  Fare: number | null;
  Cabin: string | null;
  Embarked: string | null;
}

export const titanicData: TitanicPassenger[] = [
  { PassengerId: 1, Survived: 0, Pclass: 3, Name: "Braund, Mr. Owen Harris", Sex: "male", Age: 22, SibSp: 1, Parch: 0, Ticket: "A/5 21171", Fare: 7.25, Cabin: null, Embarked: "S" },
  { PassengerId: 2, Survived: 1, Pclass: 1, Name: "Cumings, Mrs. John Bradley", Sex: "female", Age: 38, SibSp: 1, Parch: 0, Ticket: "PC 17599", Fare: 71.2833, Cabin: "C85", Embarked: "C" },
  { PassengerId: 3, Survived: 1, Pclass: 3, Name: "Heikkinen, Miss. Laina", Sex: "female", Age: 26, SibSp: 0, Parch: 0, Ticket: "STON/O2. 3101282", Fare: 7.925, Cabin: null, Embarked: "S" },
  { PassengerId: 4, Survived: 1, Pclass: 1, Name: "Futrelle, Mrs. Jacques Heath", Sex: "female", Age: 35, SibSp: 1, Parch: 0, Ticket: "113803", Fare: 53.1, Cabin: "C123", Embarked: "S" },
  { PassengerId: 5, Survived: 0, Pclass: 3, Name: "Allen, Mr. William Henry", Sex: "male", Age: 35, SibSp: 0, Parch: 0, Ticket: "373450", Fare: 8.05, Cabin: null, Embarked: "S" },
  { PassengerId: 6, Survived: 0, Pclass: 3, Name: "Moran, Mr. James", Sex: "male", Age: null, SibSp: 0, Parch: 0, Ticket: "330877", Fare: 8.4583, Cabin: null, Embarked: "Q" },
  { PassengerId: 7, Survived: 0, Pclass: 1, Name: "McCarthy, Mr. Timothy J", Sex: "male", Age: 54, SibSp: 0, Parch: 0, Ticket: "17463", Fare: 51.8625, Cabin: "E46", Embarked: "S" },
  { PassengerId: 8, Survived: 0, Pclass: 3, Name: "Palsson, Master. Gosta Leonard", Sex: "male", Age: 2, SibSp: 3, Parch: 1, Ticket: "349909", Fare: 21.075, Cabin: null, Embarked: "S" },
  { PassengerId: 9, Survived: 1, Pclass: 3, Name: "Johnson, Mrs. Oscar W", Sex: "female", Age: 27, SibSp: 0, Parch: 2, Ticket: "347742", Fare: 11.1333, Cabin: null, Embarked: "S" },
  { PassengerId: 10, Survived: 1, Pclass: 2, Name: "Nasser, Mrs. Nicholas", Sex: "female", Age: 14, SibSp: 1, Parch: 0, Ticket: "237736", Fare: 30.0708, Cabin: null, Embarked: "C" },
  { PassengerId: 11, Survived: 1, Pclass: 3, Name: "Sandstrom, Miss. Marguerite Rut", Sex: "female", Age: 4, SibSp: 1, Parch: 1, Ticket: "PP 9549", Fare: 16.7, Cabin: "G6", Embarked: "S" },
  { PassengerId: 12, Survived: 1, Pclass: 1, Name: "Bonnell, Miss. Elizabeth", Sex: "female", Age: 58, SibSp: 0, Parch: 0, Ticket: "113783", Fare: 26.55, Cabin: "C103", Embarked: "S" },
  { PassengerId: 13, Survived: 0, Pclass: 3, Name: "Saundercock, Mr. William Henry", Sex: "male", Age: 20, SibSp: 0, Parch: 0, Ticket: "A/5. 2151", Fare: 8.05, Cabin: null, Embarked: "S" },
  { PassengerId: 14, Survived: 0, Pclass: 3, Name: "Andersson, Mr. Anders Johan", Sex: "male", Age: 39, SibSp: 1, Parch: 5, Ticket: "347082", Fare: 31.275, Cabin: null, Embarked: "S" },
  { PassengerId: 15, Survived: 0, Pclass: 3, Name: "Vestrom, Miss. Hulda Amanda Adolfina", Sex: "female", Age: 14, SibSp: 0, Parch: 0, Ticket: "350406", Fare: 7.8542, Cabin: null, Embarked: "S" },
  { PassengerId: 16, Survived: 1, Pclass: 2, Name: "Hewlett, Mrs. Mary D", Sex: "female", Age: 55, SibSp: 0, Parch: 0, Ticket: "248706", Fare: 16, Cabin: null, Embarked: "S" },
  { PassengerId: 17, Survived: 0, Pclass: 3, Name: "Rice, Master. Eugene", Sex: "male", Age: 2, SibSp: 4, Parch: 1, Ticket: "382652", Fare: 29.125, Cabin: null, Embarked: "Q" },
  { PassengerId: 18, Survived: 1, Pclass: 2, Name: "Williams, Mr. Charles Eugene", Sex: "male", Age: null, SibSp: 0, Parch: 0, Ticket: "244373", Fare: 13, Cabin: null, Embarked: "S" },
  { PassengerId: 19, Survived: 0, Pclass: 3, Name: "Vander Planke, Mrs. Julius", Sex: "female", Age: 31, SibSp: 1, Parch: 0, Ticket: "345763", Fare: 18, Cabin: null, Embarked: "S" },
  { PassengerId: 20, Survived: 1, Pclass: 3, Name: "Masselmani, Mrs. Fatima", Sex: "female", Age: null, SibSp: 0, Parch: 0, Ticket: "2649", Fare: 7.225, Cabin: null, Embarked: "C" },
  // Adding more diverse data points
  { PassengerId: 21, Survived: 0, Pclass: 2, Name: "Fynney, Mr. Joseph J", Sex: "male", Age: 35, SibSp: 0, Parch: 0, Ticket: "239865", Fare: 26, Cabin: null, Embarked: "S" },
  { PassengerId: 22, Survived: 1, Pclass: 2, Name: "Beesley, Mr. Lawrence", Sex: "male", Age: 34, SibSp: 0, Parch: 0, Ticket: "248698", Fare: 13, Cabin: "D56", Embarked: "S" },
  { PassengerId: 23, Survived: 1, Pclass: 3, Name: "McGowan, Miss. Anna", Sex: "female", Age: 15, SibSp: 0, Parch: 0, Ticket: "330923", Fare: 8.0292, Cabin: null, Embarked: "Q" },
  { PassengerId: 24, Survived: 1, Pclass: 1, Name: "Sloper, Mr. William Thompson", Sex: "male", Age: 28, SibSp: 0, Parch: 0, Ticket: "113788", Fare: 35.5, Cabin: "A6", Embarked: "S" },
  { PassengerId: 25, Survived: 0, Pclass: 3, Name: "Palsson, Miss. Torborg Danira", Sex: "female", Age: 8, SibSp: 3, Parch: 1, Ticket: "349909", Fare: 21.075, Cabin: null, Embarked: "S" },
  { PassengerId: 26, Survived: 1, Pclass: 3, Name: "Asplund, Mrs. Carl Oscar", Sex: "female", Age: 38, SibSp: 1, Parch: 5, Ticket: "347077", Fare: 31.3875, Cabin: null, Embarked: "S" },
  { PassengerId: 27, Survived: 0, Pclass: 3, Name: "Emir, Mr. Farred Chehab", Sex: "male", Age: null, SibSp: 0, Parch: 0, Ticket: "2631", Fare: 7.225, Cabin: null, Embarked: "C" },
  { PassengerId: 28, Survived: 0, Pclass: 1, Name: "Fortune, Mr. Charles Alexander", Sex: "male", Age: 19, SibSp: 3, Parch: 2, Ticket: "19950", Fare: 263, Cabin: "C23 C25 C27", Embarked: "S" },
  { PassengerId: 29, Survived: 1, Pclass: 3, Name: "O'Dwyer, Miss. Ellen", Sex: "female", Age: null, SibSp: 0, Parch: 0, Ticket: "330959", Fare: 7.8792, Cabin: null, Embarked: "Q" },
  { PassengerId: 30, Survived: 0, Pclass: 3, Name: "Todoroff, Mr. Lalio", Sex: "male", Age: null, SibSp: 0, Parch: 0, Ticket: "349216", Fare: 7.8958, Cabin: null, Embarked: "S" }
];

// Extended dataset for more comprehensive analysis
export const extendedTitanicData: TitanicPassenger[] = [
  ...titanicData,
  // Additional passengers for better statistical analysis
  { PassengerId: 31, Survived: 1, Pclass: 1, Name: "Warren, Mrs. Frank Manley", Sex: "female", Age: 60, SibSp: 1, Parch: 0, Ticket: "110813", Fare: 75.25, Cabin: "D37", Embarked: "C" },
  { PassengerId: 32, Survived: 1, Pclass: 1, Name: "Peacock, Mrs. Benjamin", Sex: "female", Age: 26, SibSp: 0, Parch: 2, Ticket: "113776", Fare: 55.4417, Cabin: "D35", Embarked: "C" },
  { PassengerId: 33, Survived: 1, Pclass: 2, Name: "Troupiansky, Mr. Moses Aaron", Sex: "male", Age: 23, SibSp: 0, Parch: 0, Ticket: "233639", Fare: 13, Cabin: null, Embarked: "S" },
  { PassengerId: 34, Survived: 0, Pclass: 2, Name: "Watson, Mr. Ennis Hastings", Sex: "male", Age: null, SibSp: 0, Parch: 0, Ticket: "239856", Fare: 0, Cabin: null, Embarked: "S" },
  { PassengerId: 35, Survived: 0, Pclass: 3, Name: "Robins, Mr. Alexander A", Sex: "male", Age: 50, SibSp: 1, Parch: 0, Ticket: "A/5. 3337", Fare: 14.5, Cabin: null, Embarked: "S" },
  { PassengerId: 36, Survived: 1, Pclass: 3, Name: "Kink, Mrs. Anton", Sex: "female", Age: 22, SibSp: 2, Parch: 0, Ticket: "315151", Fare: 20.2125, Cabin: null, Embarked: "S" },
  { PassengerId: 37, Survived: 1, Pclass: 3, Name: "Mamee, Mr. Hanna", Sex: "male", Age: null, SibSp: 0, Parch: 0, Ticket: "2677", Fare: 7.2292, Cabin: null, Embarked: "C" },
  { PassengerId: 38, Survived: 0, Pclass: 3, Name: "Cann, Mr. Ernest Charles", Sex: "male", Age: 21, SibSp: 0, Parch: 0, Ticket: "A./5. 2152", Fare: 8.05, Cabin: null, Embarked: "S" },
  { PassengerId: 39, Survived: 0, Pclass: 3, Name: "Vander Planke, Miss. Augusta Maria", Sex: "female", Age: 18, SibSp: 2, Parch: 0, Ticket: "345764", Fare: 18, Cabin: null, Embarked: "S" },
  { PassengerId: 40, Survived: 1, Pclass: 3, Name: "Nicola-Yarred, Miss. Jamila", Sex: "female", Age: 14, SibSp: 1, Parch: 0, Ticket: "2651", Fare: 11.2417, Cabin: null, Embarked: "C" },
  // More passengers across different classes and demographics
  { PassengerId: 41, Survived: 0, Pclass: 3, Name: "Ahlin, Mrs. Johan", Sex: "female", Age: 40, SibSp: 1, Parch: 0, Ticket: "7546", Fare: 9.475, Cabin: null, Embarked: "S" },
  { PassengerId: 42, Survived: 0, Pclass: 2, Name: "Turpin, Mr. William John Robert", Sex: "male", Age: 29, SibSp: 1, Parch: 0, Ticket: "11771", Fare: 21, Cabin: null, Embarked: "S" },
  { PassengerId: 43, Survived: 0, Pclass: 3, Name: "Kraeff, Mr. Theodor", Sex: "male", Age: null, SibSp: 0, Parch: 0, Ticket: "349253", Fare: 7.8958, Cabin: null, Embarked: "C" },
  { PassengerId: 44, Survived: 1, Pclass: 2, Name: "Laroche, Miss. Simonne Marie Anne Andree", Sex: "female", Age: 3, SibSp: 1, Parch: 2, Ticket: "SC/Paris 2123", Fare: 41.5792, Cabin: null, Embarked: "C" },
  { PassengerId: 45, Survived: 1, Pclass: 3, Name: "Devaney, Miss. Margaret Delia", Sex: "female", Age: 19, SibSp: 0, Parch: 0, Ticket: "330958", Fare: 7.8792, Cabin: null, Embarked: "Q" },
  { PassengerId: 46, Survived: 0, Pclass: 3, Name: "Rogers, Mr. William John", Sex: "male", Age: null, SibSp: 0, Parch: 0, Ticket: "S.C./A.4. 23567", Fare: 8.05, Cabin: null, Embarked: "S" },
  { PassengerId: 47, Survived: 0, Pclass: 3, Name: "Lennon, Mr. Denis", Sex: "male", Age: null, SibSp: 1, Parch: 0, Ticket: "370371", Fare: 15.5, Cabin: null, Embarked: "Q" },
  { PassengerId: 48, Survived: 1, Pclass: 3, Name: "O'Driscoll, Miss. Bridget", Sex: "female", Age: null, SibSp: 0, Parch: 0, Ticket: "14311", Fare: 7.75, Cabin: null, Embarked: "Q" },
  { PassengerId: 49, Survived: 0, Pclass: 3, Name: "Samaan, Mr. Youssef", Sex: "male", Age: null, SibSp: 2, Parch: 0, Ticket: "2662", Fare: 21.6792, Cabin: null, Embarked: "C" },
  { PassengerId: 50, Survived: 0, Pclass: 3, Name: "Arnold-Franchi, Mrs. Josef", Sex: "female", Age: 18, SibSp: 1, Parch: 0, Ticket: "349237", Fare: 17.8, Cabin: null, Embarked: "S" }
];