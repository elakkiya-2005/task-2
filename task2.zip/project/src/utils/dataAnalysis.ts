import { TitanicPassenger } from '../data/titanicData';

export interface DataSummary {
  totalPassengers: number;
  survivalRate: number;
  avgAge: number;
  missingAges: number;
  missingFares: number;
  genderDistribution: { male: number; female: number };
  classDistribution: { first: number; second: number; third: number };
  embarkedDistribution: { S: number; C: number; Q: number; unknown: number };
}

export interface SurvivalByCategory {
  byGender: { male: number; female: number };
  byClass: { first: number; second: number; third: number };
  byEmbarked: { S: number; C: number; Q: number };
}

export function calculateDataSummary(data: TitanicPassenger[]): DataSummary {
  const totalPassengers = data.length;
  const survivors = data.filter(p => p.Survived === 1).length;
  const survivalRate = (survivors / totalPassengers) * 100;
  
  const validAges = data.filter(p => p.Age !== null).map(p => p.Age!);
  const avgAge = validAges.reduce((sum, age) => sum + age, 0) / validAges.length;
  const missingAges = data.filter(p => p.Age === null).length;
  const missingFares = data.filter(p => p.Fare === null).length;
  
  const genderDistribution = {
    male: data.filter(p => p.Sex === 'male').length,
    female: data.filter(p => p.Sex === 'female').length
  };
  
  const classDistribution = {
    first: data.filter(p => p.Pclass === 1).length,
    second: data.filter(p => p.Pclass === 2).length,
    third: data.filter(p => p.Pclass === 3).length
  };
  
  const embarkedDistribution = {
    S: data.filter(p => p.Embarked === 'S').length,
    C: data.filter(p => p.Embarked === 'C').length,
    Q: data.filter(p => p.Embarked === 'Q').length,
    unknown: data.filter(p => p.Embarked === null).length
  };
  
  return {
    totalPassengers,
    survivalRate,
    avgAge,
    missingAges,
    missingFares,
    genderDistribution,
    classDistribution,
    embarkedDistribution
  };
}

export function calculateSurvivalRates(data: TitanicPassenger[]): SurvivalByCategory {
  const byGender = {
    male: calculateCategorySurvival(data, p => p.Sex === 'male'),
    female: calculateCategorySurvival(data, p => p.Sex === 'female')
  };
  
  const byClass = {
    first: calculateCategorySurvival(data, p => p.Pclass === 1),
    second: calculateCategorySurvival(data, p => p.Pclass === 2),
    third: calculateCategorySurvival(data, p => p.Pclass === 3)
  };
  
  const byEmbarked = {
    S: calculateCategorySurvival(data, p => p.Embarked === 'S'),
    C: calculateCategorySurvival(data, p => p.Embarked === 'C'),
    Q: calculateCategorySurvival(data, p => p.Embarked === 'Q')
  };
  
  return { byGender, byClass, byEmbarked };
}

function calculateCategorySurvival(data: TitanicPassenger[], filter: (p: TitanicPassenger) => boolean): number {
  const categoryData = data.filter(filter);
  if (categoryData.length === 0) return 0;
  const survivors = categoryData.filter(p => p.Survived === 1).length;
  return (survivors / categoryData.length) * 100;
}

export function getAgeDistribution(data: TitanicPassenger[]): { ageRange: string; count: number; survived: number }[] {
  const validAges = data.filter(p => p.Age !== null);
  const ageRanges = [
    { min: 0, max: 10, label: '0-10' },
    { min: 11, max: 20, label: '11-20' },
    { min: 21, max: 30, label: '21-30' },
    { min: 31, max: 40, label: '31-40' },
    { min: 41, max: 50, label: '41-50' },
    { min: 51, max: 60, label: '51-60' },
    { min: 61, max: 100, label: '60+' }
  ];
  
  return ageRanges.map(range => {
    const inRange = validAges.filter(p => p.Age! >= range.min && p.Age! <= range.max);
    const survived = inRange.filter(p => p.Survived === 1).length;
    return {
      ageRange: range.label,
      count: inRange.length,
      survived
    };
  });
}

export function getFareDistribution(data: TitanicPassenger[]): { fareRange: string; count: number; survived: number }[] {
  const validFares = data.filter(p => p.Fare !== null);
  const fareRanges = [
    { min: 0, max: 10, label: '$0-10' },
    { min: 10, max: 25, label: '$10-25' },
    { min: 25, max: 50, label: '$25-50' },
    { min: 50, max: 100, label: '$50-100' },
    { min: 100, max: 1000, label: '$100+' }
  ];
  
  return fareRanges.map(range => {
    const inRange = validFares.filter(p => p.Fare! >= range.min && p.Fare! < range.max);
    const survived = inRange.filter(p => p.Survived === 1).length;
    return {
      fareRange: range.label,
      count: inRange.length,
      survived
    };
  });
}

export function cleanData(data: TitanicPassenger[]): TitanicPassenger[] {
  return data.map(passenger => ({
    ...passenger,
    Age: passenger.Age ?? getMedianAge(data),
    Fare: passenger.Fare ?? getMedianFare(data),
    Embarked: passenger.Embarked ?? 'S'
  }));
}

function getMedianAge(data: TitanicPassenger[]): number {
  const validAges = data.filter(p => p.Age !== null).map(p => p.Age!).sort((a, b) => a - b);
  const mid = Math.floor(validAges.length / 2);
  return validAges.length % 2 === 0 
    ? (validAges[mid - 1] + validAges[mid]) / 2
    : validAges[mid];
}

function getMedianFare(data: TitanicPassenger[]): number {
  const validFares = data.filter(p => p.Fare !== null).map(p => p.Fare!).sort((a, b) => a - b);
  const mid = Math.floor(validFares.length / 2);
  return validFares.length % 2 === 0 
    ? (validFares[mid - 1] + validFares[mid]) / 2
    : validFares[mid];
}