import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement,
} from 'chart.js';
import { Bar, Pie, Line } from 'react-chartjs-2';
import { DataSummary, SurvivalByCategory } from '../utils/dataAnalysis';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
);

interface ChartsProps {
  summary: DataSummary;
  survivalRates: SurvivalByCategory;
  ageDistribution: { ageRange: string; count: number; survived: number }[];
  fareDistribution: { fareRange: string; count: number; survived: number }[];
}

export function Charts({ summary, survivalRates, ageDistribution, fareDistribution }: ChartsProps) {
  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const pieOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
  };

  // Gender Distribution Chart
  const genderData = {
    labels: ['Male', 'Female'],
    datasets: [
      {
        label: 'Passengers',
        data: [summary.genderDistribution.male, summary.genderDistribution.female],
        backgroundColor: ['#3B82F6', '#EC4899'],
        borderColor: ['#2563EB', '#DB2777'],
        borderWidth: 2,
      },
    ],
  };

  // Class Distribution Chart
  const classData = {
    labels: ['First Class', 'Second Class', 'Third Class'],
    datasets: [
      {
        label: 'Passengers',
        data: [summary.classDistribution.first, summary.classDistribution.second, summary.classDistribution.third],
        backgroundColor: ['#8B5CF6', '#06B6D4', '#F97316'],
        borderColor: ['#7C3AED', '#0891B2', '#EA580C'],
        borderWidth: 2,
      },
    ],
  };

  // Survival Rates by Category
  const survivalData = {
    labels: ['Male', 'Female', '1st Class', '2nd Class', '3rd Class'],
    datasets: [
      {
        label: 'Survival Rate (%)',
        data: [
          survivalRates.byGender.male,
          survivalRates.byGender.female,
          survivalRates.byClass.first,
          survivalRates.byClass.second,
          survivalRates.byClass.third,
        ],
        backgroundColor: 'rgba(34, 197, 94, 0.8)',
        borderColor: 'rgb(34, 197, 94)',
        borderWidth: 2,
      },
    ],
  };

  // Age Distribution Chart
  const ageData = {
    labels: ageDistribution.map(d => d.ageRange),
    datasets: [
      {
        label: 'Total Passengers',
        data: ageDistribution.map(d => d.count),
        backgroundColor: 'rgba(99, 102, 241, 0.8)',
        borderColor: 'rgb(99, 102, 241)',
        borderWidth: 2,
      },
      {
        label: 'Survivors',
        data: ageDistribution.map(d => d.survived),
        backgroundColor: 'rgba(34, 197, 94, 0.8)',
        borderColor: 'rgb(34, 197, 94)',
        borderWidth: 2,
      },
    ],
  };

  // Fare Distribution Chart
  const fareData = {
    labels: fareDistribution.map(d => d.fareRange),
    datasets: [
      {
        label: 'Total Passengers',
        data: fareDistribution.map(d => d.count),
        backgroundColor: 'rgba(249, 115, 22, 0.8)',
        borderColor: 'rgb(249, 115, 22)',
        borderWidth: 2,
      },
      {
        label: 'Survivors',
        data: fareDistribution.map(d => d.survived),
        backgroundColor: 'rgba(34, 197, 94, 0.8)',
        borderColor: 'rgb(34, 197, 94)',
        borderWidth: 2,
      },
    ],
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Gender Distribution */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Gender Distribution</h3>
        <Pie data={genderData} options={pieOptions} />
      </div>

      {/* Class Distribution */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Class Distribution</h3>
        <Pie data={classData} options={pieOptions} />
      </div>

      {/* Survival Rates */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Survival Rates by Category</h3>
        <Bar data={survivalData} options={chartOptions} />
      </div>

      {/* Age Distribution */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Age Distribution</h3>
        <Bar data={ageData} options={chartOptions} />
      </div>

      {/* Fare Distribution */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 lg:col-span-2">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Fare Distribution</h3>
        <Bar data={fareData} options={chartOptions} />
      </div>
    </div>
  );
}