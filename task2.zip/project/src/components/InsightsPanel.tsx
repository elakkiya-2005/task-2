import React from 'react';
import { TrendingUp, Users, DollarSign, MapPin, AlertCircle } from 'lucide-react';
import { DataSummary, SurvivalByCategory } from '../utils/dataAnalysis';

interface InsightsPanelProps {
  summary: DataSummary;
  survivalRates: SurvivalByCategory;
}

export function InsightsPanel({ summary, survivalRates }: InsightsPanelProps) {
  const insights = [
    {
      icon: Users,
      title: 'Gender Impact on Survival',
      description: `Women had a ${survivalRates.byGender.female.toFixed(1)}% survival rate compared to ${survivalRates.byGender.male.toFixed(1)}% for men`,
      type: 'gender',
      color: 'text-pink-600',
      bgColor: 'bg-pink-50',
      borderColor: 'border-pink-200'
    },
    {
      icon: TrendingUp,
      title: 'Class Privilege',
      description: `First-class passengers had ${survivalRates.byClass.first.toFixed(1)}% survival rate vs ${survivalRates.byClass.third.toFixed(1)}% for third-class`,
      type: 'class',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200'
    },
    {
      icon: MapPin,
      title: 'Embarkation Port',
      description: `Cherbourg (C) passengers had the highest survival rate at ${survivalRates.byEmbarked.C.toFixed(1)}%`,
      type: 'embarked',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200'
    },
    {
      icon: AlertCircle,
      title: 'Data Quality',
      description: `${summary.missingAges} passengers missing age data, ${summary.missingFares} missing fare data`,
      type: 'quality',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200'
    }
  ];

  const keyFindings = [
    "Women and children first policy was clearly implemented - females had 4x higher survival rate",
    "Passenger class was a strong predictor of survival - wealth literally bought survival",
    "Younger passengers had better survival rates, especially children under 10",
    "Port of embarkation correlates with survival, likely due to class distribution",
    "Third-class passengers faced significant barriers to evacuation"
  ];

  return (
    <div className="space-y-8">
      {/* Key Insights Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {insights.map((insight, index) => {
          const Icon = insight.icon;
          return (
            <div key={index} className={`${insight.bgColor} ${insight.borderColor} border rounded-xl p-6 hover:shadow-md transition-shadow duration-200`}>
              <div className="flex items-start space-x-4">
                <div className={`${insight.color} p-2 rounded-lg bg-white shadow-sm`}>
                  <Icon className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <h4 className={`font-semibold ${insight.color} mb-2`}>{insight.title}</h4>
                  <p className="text-gray-700 text-sm leading-relaxed">{insight.description}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Key Findings */}
      <div className="bg-gradient-to-br from-indigo-50 to-blue-50 rounded-xl p-6 border border-indigo-200">
        <h3 className="text-xl font-semibold text-indigo-900 mb-4 flex items-center">
          <TrendingUp className="h-5 w-5 mr-2" />
          Key Findings from Analysis
        </h3>
        <ul className="space-y-3">
          {keyFindings.map((finding, index) => (
            <li key={index} className="flex items-start space-x-3">
              <div className="w-2 h-2 bg-indigo-500 rounded-full mt-2 flex-shrink-0"></div>
              <p className="text-gray-700 leading-relaxed">{finding}</p>
            </li>
          ))}
        </ul>
      </div>

      {/* Statistical Summary */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Statistical Summary</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-2xl font-bold text-blue-600">{summary.genderDistribution.female}</p>
            <p className="text-sm text-gray-600">Female Passengers</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-2xl font-bold text-purple-600">{summary.classDistribution.first}</p>
            <p className="text-sm text-gray-600">First Class</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-2xl font-bold text-green-600">{summary.avgAge.toFixed(0)}</p>
            <p className="text-sm text-gray-600">Avg Age (years)</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-2xl font-bold text-orange-600">{summary.embarkedDistribution.S}</p>
            <p className="text-sm text-gray-600">From Southampton</p>
          </div>
        </div>
      </div>
    </div>
  );
}