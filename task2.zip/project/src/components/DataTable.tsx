import React from 'react';
import { TitanicPassenger } from '../data/titanicData';

interface DataTableProps {
  data: TitanicPassenger[];
  maxRows?: number;
}

export function DataTable({ data, maxRows = 10 }: DataTableProps) {
  const displayData = maxRows ? data.slice(0, maxRows) : data;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <h3 className="text-lg font-semibold text-gray-900">Dataset Preview</h3>
        <p className="text-sm text-gray-600 mt-1">
          Showing {displayData.length} of {data.length} passengers
        </p>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Survived</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Class</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sex</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Age</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fare</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Embarked</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {displayData.map((passenger, index) => (
              <tr key={passenger.PassengerId} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{passenger.PassengerId}</td>
                <td className="px-4 py-3 text-sm text-gray-900 max-w-xs truncate">{passenger.Name}</td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    passenger.Survived ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {passenger.Survived ? 'Yes' : 'No'}
                  </span>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    passenger.Pclass === 1 ? 'bg-purple-100 text-purple-800' :
                    passenger.Pclass === 2 ? 'bg-blue-100 text-blue-800' :
                    'bg-orange-100 text-orange-800'
                  }`}>
                    {passenger.Pclass}
                  </span>
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 capitalize">{passenger.Sex}</td>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                  {passenger.Age ?? <span className="text-gray-400 italic">Missing</span>}
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                  {passenger.Fare ? `$${passenger.Fare.toFixed(2)}` : <span className="text-gray-400 italic">Missing</span>}
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                  {passenger.Embarked ?? <span className="text-gray-400 italic">Missing</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}